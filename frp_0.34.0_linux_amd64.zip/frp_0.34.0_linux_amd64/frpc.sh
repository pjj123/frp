#!/bin/bash

/home/pjj/frp/frp_0.34.0_linux_amd64/frpc -c /home/pjj/frp/frp_0.34.0_linux_amd64/frpc.ini
